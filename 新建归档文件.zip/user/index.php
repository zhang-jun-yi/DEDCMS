<?php
/**
 * @version        $Id: index.php 1 8:24 2010年7月9日Z tianya $
 * @package        DedeCMS.Member
 * @copyright      Copyright (c) 2007 - 2010, DesDev, Inc.
 * @license        http://help.dedecms.com/usersguide/license.html
 * @link           http://www.dedecms.com
 */
require_once(dirname(__FILE__)."/config.php");

$uid=empty($uid)? "" : RemoveXSS($uid); 
if(empty($action)) $action = '';
if(empty($aid)) $aid = '';

$menutype = 'mydede';
if ( preg_match("#PHP (.*) Development Server#",$_SERVER['SERVER_SOFTWARE']) )
{
    if ( $_SERVER['REQUEST_URI'] == dirname($_SERVER['SCRIPT_NAME']) )
    {
        header('HTTP/1.1 301 Moved Permanently');
        header('Location:'.$_SERVER['REQUEST_URI'].'/');
    }
}
//会员后台
if($uid=='')
{
    $iscontrol = 'yes';
    //未登录
    if(!$cfg_ml->IsLogin())
    {
        include_once(dirname(__FILE__)."/login.php");
    }
    else//已登录
    {
        $user=$dsql->GetOne("SELECT  * FROM `#@__member` WHERE mid='".$cfg_ml->M_ID."'");
        if(empty( $user) || $user == '')
            include_once(dirname(__FILE__)."/login.php");
        else{
            $row = $user;
            $dpl = new DedeTemplate();
            $tpl = dirname(__FILE__)."/templets/index.htm";
            $dpl->LoadTemplate($tpl);
            $dpl->display();
        }
      
    }
}
else
{
    $dpl = new DedeTemplate();
    $tpl = dirname(__FILE__)."/templets/index.htm";
    $dpl->LoadTemplate($tpl);
    $dpl->display();
}