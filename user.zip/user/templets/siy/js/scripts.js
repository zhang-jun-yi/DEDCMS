
jQuery(document).ready(function() {
	
    /*
        Fullscreen background
    */
    $.backstretch(bloghost+"zb_users/plugin/ZCenter/static/assets/img/backgrounds/1.jpg");
        
    
});
