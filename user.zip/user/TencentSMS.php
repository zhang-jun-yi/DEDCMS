<?php
/**
 * @version        $Id: TencentSMS.php 
 * @link     
 */

 class TencentSMS 
 {
     //腾讯云短信必须参数
    protected $AppID ='1400502956';
    protected $AppKey ='12a1cd88863700cb1f9d8b59d87acaa1';
 }
 

 
