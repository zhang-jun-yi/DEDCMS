<?php
/**
 * 生成网站地图向导
 *
 * @version        $Id: makehtml_map_guide.php 1 11:17 2010年7月19日Z tianya $
 * @package        DedeCMS.Administrator
 * @copyright      Copyright (c) 2007 - 2010, DesDev, Inc.
 * @license        http://help.dedecms.com/usersguide/license.html
 * @link           http://www.dedecms.com
 */
require_once(dirname(__FILE__)."/config.php");
include DedeInclude('templets/makehtml_map_guide.htm');