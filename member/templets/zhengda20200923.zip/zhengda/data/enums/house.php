<?php
global $em_houses;
$em_houses = array();
$em_houses['1'] = '租房';
$em_houses['2'] = '一房以上';
$em_houses['3'] = '两房以上';
$em_houses['4'] = '大户/别墅';
?>