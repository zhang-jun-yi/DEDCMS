<?php
/**
 * 更新服务器，如果有变动，请到 http://bbs.dedecms.com 查询
 *
 * @version        $Id: config_update.php 1 11:36 2011-2-21 tianya $
 * @package        DedeCMS.Administrator
 * @copyright      Copyright (c) 2007 - 2010, DesDev, Inc.
 * @license        http://help.dedecms.com/usersguide/license.html
 * @link           http://www.dedecms.com
 */

//更新服务器，如果有变动，请到 http://bbs.dedecms.com 查询

define('UPDATEHOST', 'http://updatenew.dedecms.com/base-v57/');
define('LINKHOST', 'http://flink.dedecms.com/server_url.php');
